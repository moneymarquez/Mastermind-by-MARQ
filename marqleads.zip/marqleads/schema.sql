-- Masterminds: leads table + storage bucket
-- Run in Supabase SQL editor before the first export.

create table if not exists public.leads (
  id                      uuid primary key default gen_random_uuid(),
  workspace_id            uuid,                       -- matches your multi-tenant pattern
  place_id                text unique not null,       -- upsert key

  -- who
  business_name           text not null,
  phone                   text,
  owner_name              text,
  owner_is_agent_only     boolean default false,
  registered_agent        text,
  registry_legal_name     text,
  registry_confidence     int,
  registry_note           text,
  registry_url            text,

  -- where
  address                 text,
  city                    text,
  lat                     double precision,
  lng                     double precision,

  -- what
  category                text,
  search_category         text,
  website                 text,
  summary                 text,

  -- why they're a lead
  rating                  numeric(2,1),
  review_count            int,
  days_since_last_review  int,
  fizzle_score            int,
  tier                    text check (tier in ('A','B','C')),
  fizzle_reasons          jsonb,

  -- imagery
  maps_url                text,
  streetview_url          text,
  streetview_path         text,       -- object path in lead-media bucket
  photo_path              text,

  -- pipeline
  status                  text default 'new'
                          check (status in ('new','queued','called','no_answer',
                                            'callback','interested','not_interested',
                                            'client','dead')),
  call_notes              text,
  last_called_at          timestamptz,
  call_count              int default 0,
  next_followup_at        timestamptz,

  created_at              timestamptz default now(),
  updated_at              timestamptz default now()
);

create index if not exists leads_tier_score_idx
  on public.leads (tier, fizzle_score desc);
create index if not exists leads_status_idx on public.leads (status);
create index if not exists leads_workspace_idx on public.leads (workspace_id);
create index if not exists leads_followup_idx
  on public.leads (next_followup_at) where next_followup_at is not null;

-- keep updated_at honest
create or replace function public.touch_updated_at()
returns trigger language plpgsql as $$
begin new.updated_at = now(); return new; end $$;

drop trigger if exists leads_touch on public.leads;
create trigger leads_touch before update on public.leads
  for each row execute function public.touch_updated_at();

-- RLS: owner-only. Clients must never see the prospect list.
alter table public.leads enable row level security;

drop policy if exists "owners read own workspace leads" on public.leads;
create policy "owners read own workspace leads" on public.leads
  for select using (
    exists (
      select 1 from public.profiles p
      where p.id = auth.uid()
        and p.role = 'owner'
        and (p.workspace_id = leads.workspace_id or leads.workspace_id is null)
    )
  );

drop policy if exists "owners write own workspace leads" on public.leads;
create policy "owners write own workspace leads" on public.leads
  for all using (
    exists (
      select 1 from public.profiles p
      where p.id = auth.uid()
        and p.role = 'owner'
        and (p.workspace_id = leads.workspace_id or leads.workspace_id is null)
    )
  );

-- Storage bucket for lead imagery. PRIVATE — app serves signed URLs.
insert into storage.buckets (id, name, public)
values ('lead-media', 'lead-media', false)
on conflict (id) do nothing;

drop policy if exists "owners read lead media" on storage.objects;
create policy "owners read lead media" on storage.objects
  for select using (
    bucket_id = 'lead-media'
    and exists (
      select 1 from public.profiles p
      where p.id = auth.uid() and p.role = 'owner'
    )
  );
