# Marq Leads — fizzled-business finder

Finds local businesses that **were good and lost momentum**, scores them, pulls the owner's name from the Utah registry, and gives you a call sheet sorted by fit.

## Why the old pipeline hit 30%

The old flow was: registry → owner name → people-search → phone. The people-search step is the leak. Registry names don't match storefront names, half of Utah LLCs list a formation service as principal, common names return ten hits, and the number you get is a stale personal cell.

This flow is: Google Places → **business phone** (95%+ present) → fizzle score → registry → **owner name** (when confidently matched). You call the business and ask for the owner by name. At a small business that's the owner or one handoff away, and a name gets past gatekeepers that "the owner" doesn't.

No people-search. No personal phone numbers. Public business listings and public corporate records only.

## Setup

```bash
git clone <this>  &&  cd marqleads
pip install -r requirements.txt
cp config.example.yaml config.yaml     # fill in your Places key
```

**Google Cloud:** enable **Places API (New)** — not the legacy one — and create a key restricted to it.

**OpenCorporates:** works without a token for small runs. Get a free token at opencorporates.com/api_accounts/new for 500 lookups/month; paid tiers above that.

## Run

```bash
python -m leads.pipeline --config config.yaml --dry-run           # discovery only, no Details spend
python -m leads.pipeline --config config.yaml                     # full run, CSV out
python -m leads.pipeline --config config.yaml --images            # + Street View & place photos (tier A/B only)
python -m leads.pipeline --config config.yaml --images --push     # + push into Masterminds
python -m leads.pipeline --config config.yaml --skip-registry     # skip owner lookup (fast, cheap)
python -m leads.pipeline --config config.yaml --fresh             # ignore checkpoint, start over
```

**Suggested first run:** `--dry-run` to see how many businesses exist, then a full run
without `--images` to see your real tier-A count, then re-run with `--images --push`
once you know the yield is worth it.

It checkpoints after every 10 businesses. Ctrl-C and re-run — it picks up where it left off.

## Cost

Rough, check current Google pricing:
- Text Search ~$32/1k · Place Details w/ reviews ~$25/1k · Street View Static ~$7/1k · Place Photos ~$7/1k
- Details only runs on businesses passing the pre-filter (~40–60% of discovered).
  Images only run on tier A/B (a fraction of those).
- **500 businesses examined ≈ $25–35 all in.** Google's $200/mo free credit covers early runs.

**Cost scales with businesses *examined*, not leads *kept*.** Roughly 10–20% of examined
businesses end up tier A/B. So ~2,000 qualified leads means examining 10,000–15,000
businesses — $600–900, not $100.

Also worth knowing: five cities × fourteen categories is on the order of 3,000–5,000 total
businesses, yielding maybe 200–400 tier-A fits. Getting to thousands means expanding well
beyond the Salt Lake valley, and then you're cold-calling people who can't meet you.
**Run the local config first, see the real tier-A count, then decide about expanding.**

## Imagery

`--images` downloads two things per tier-A/B lead:

- **Street View** of the storefront — via Street View Static API (~$7/1k)
- **A Google place photo** — owner or customer uploaded, often better than Street View for
  a restaurant interior or a truck (~$7/1k via Places Photos)

Before every Street View call the code hits the **free metadata endpoint** to check imagery
actually exists at those coordinates. No paying for grey "no imagery available" boxes.

Enable in Cloud Console and add to your key's restriction list:
- **Street View Static API**
- **Places API (New)** already covers place photos

Free `maps_url` and `streetview_url` links are always in the CSV regardless of `--images` —
those are plain browser links, no API, no cost. If you only need to eyeball a place before
dialing, skip `--images` entirely and just click the link.

## Pushing into Masterminds

1. Run `schema.sql` in the Supabase SQL editor — creates the `leads` table, indexes,
   RLS policies, and the private `lead-media` bucket.
2. Fill the `supabase:` block in `config.yaml` with your project URL and **service role** key.
3. Run with `--push`.

Upserts on `place_id`, so re-running never duplicates — it refreshes scores on businesses
you've already seen. Images upload to the private bucket; the app generates signed URLs.

RLS is owner-only. Clients must never see your prospect list.

The table carries a call-tracking side: `status` (new → queued → called → interested →
client), `call_notes`, `last_called_at`, `call_count`, `next_followup_at`. That's your
call sheet living in the app instead of a spreadsheet.

**The service role key bypasses RLS.** Server-side only. Never in the app bundle, never in git.
`config.yaml` is already gitignored.

## Output

`leads_output.csv`, sorted by score. Columns that matter for calling:

| column | use |
|---|---|
| `tier` | A = call first. B = call. C = only if you run out. |
| `score` | 0–100 |
| `phone` | business line |
| `owner_or_principal` | ask for this person by name. `[agent]` prefix = registered agent, probably not the owner |
| `fizzle_reasons` | your opener. "I noticed your last Google review was 14 months ago" |
| `days_since_last_review` | the number to say out loud |
| `registry_note` | if it says "no confident match," skip the name and ask "who handles marketing?" |
| `best_time_to_call` | category-specific window when the owner actually picks up |
| `band_used` | which review band applied, so you can sanity-check the floor |
| `maps_url` | click to open their Google listing before you dial |
| `streetview_url` | click to see the storefront |

## What gets filtered out before scoring

**Franchises and chains.** A Subway or Great Clips location cannot hire you — marketing
is set at corporate and whoever answers has no spend authority. These score *well*
(lots of reviews, neglected local listings), so without this filter they'd sit at the
top of your A tier and eat your dial time. Two checks: a known-brand list, and
duplicate-name detection within the run (3+ locations of the same name = multi-unit
operator, even a regional one nobody's heard of).

**Suppressed numbers.** Anything in `do_not_call.txt` is removed from the output.
Append to it the moment someone asks you to stop.

## How the score works

Needs **both**: proof they were good, proof they slipped.

- **Strong period** (up to 40): total review count, rating ≥ 4.5
- **Falloff** (up to 45): days since most recent Google review. 365+ days = full points
- **Website neglect** (up to 20): old copyright year, no site, not mobile-responsive, builder defaults

**The fizzle window is the core of it.** The pitch is "you were good, let's get that
back" — that lands hardest on someone who went quiet 5–12 months ago and still feels
the sting. A business dark for three years isn't fizzling, it's mostly dormant, and
it's a different conversation. So the score **peaks inside 150–365 days and decays
outside it** in both directions. Adjust in `config.yaml` under `fizzle_window`.

**Fall-from-height.** Going quiet only matters if they were busy first. Google returns
the 5 newest reviews; the span between them measures how fast reviews were arriving
right before the business stopped. A place pulling 5/month that stopped fell from a
real height. One that trickled 0.3/month for years never fell — "let's get back to
what you had" is the wrong pitch for them. Compared against a category-expected rate,
since 2/month is healthy for a plumber and weak for a restaurant.

**Two caps.** Still active (last review under 60 days) caps at 45 — nothing to win
back yet. Never fell (always-slow pace) caps at 62 — no height to point at. Both stay
in the list; neither can reach tier A.

**Review counts are scored relative to category, not absolute.** Review rates differ
hugely by business type: a restaurant collects roughly one review per 100–200 customers,
while a plumber serves far fewer customers at much higher ticket and often gets a review
from a decent fraction of them. A plumber with 40 reviews is well established; a
restaurant with 40 reviews is small. One flat threshold throws away good trade leads and
lets weak restaurants through.

Floors and "strong" marks per category live in `CATEGORY_BANDS` in `fizzle.py`, overridable
in config. Roughly: restaurants/cafes/bars floor 40 · salons/spas 25 · trades 12–15 ·
auto repair and dentists 25–30.

**Disqualified (tier X):** not operational · below the category floor (never had a strong
period — wrong pitch) · rating under 3.8 (product is the problem, not visibility — you
can't fix that with marketing and shouldn't take the money) · no phone · franchise/chain.

## Calling compliance — read this

**Not legal advice. Read the rules yourself before running volume.**

The National DNC Registry covers *residential* numbers, and B2B calls are largely
exempt — but a lot of small businesses use a cell or home line as their business
number, and the exemption is about the call's purpose, not the number. Utah also has
its own state DNC list and telephone solicitation rules. Enforcement has been unkind
to people who assumed the B2B exemption covered everything.

What the code does for you:
- `do_not_call.txt` — your own suppression list, checked on every run
- Call-window check (9am–6pm Mountain, no weekends — tighter than the federal 8am–9pm floor on purpose)
- `best_time_to_call` per lead by category: restaurants 2–4pm between rushes, trades 7–8am or 4–6pm since they're on jobs midday, salons Tue–Thu because Mondays are often closed

What it can't do: if someone asks you to stop, that's on you to honor — add them to
`do_not_call.txt` immediately and never call again.

## Known limits

- **Google returns only the 5 newest reviews.** You get "last review date," not the full curve. That's enough for the signal but it's a proxy. When you're on the phone, pull up their profile and look at the actual spread.
- **Instagram / Facebook dormancy is not detected.** Both block scraping and it violates their terms. Check manually for A-tier leads before calling — takes 20 seconds each.
- **Registry match is fuzzy.** Confidence < 70 → owner left blank on purpose. Wrong name is worse than no name.
- **OpenCorporates lags** Utah's registry by days to weeks. Fine for this.

## Scaling past ~1,000 leads

Buy Utah's corporate database as a flat file (Division of Corporations → Data Sales, one-time fee). Load it locally and fuzzy-match against 500k rows with zero API limits. `registry.py` is the only thing that changes.

## Calling from the sheet

Tier A, top down. Open the Google profile before you dial. The `fizzle_reasons` column is the first sentence of the call:

> "Hey, is Maria around? — Hi Maria, I'm Marq, I do marketing for local places in Sandy. I was looking at your Google profile — you've got 240 reviews at 4.6 stars, which is great, but the last one was over a year ago. That's usually a sign the phone's gotten quieter. Is that right?"

Specific beats pitch. Let them tell you it's true.
