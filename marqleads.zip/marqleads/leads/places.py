"""
Google Places API (New) discovery.

Two calls per business:
  1. Text Search  — find businesses by category + location
  2. Place Details — phone, website, reviews (Google returns max 5 most recent)

Cost note: Text Search ~$32/1k, Details with reviews ~$25/1k (check current pricing).
500 businesses ≈ $30. Keep max_businesses_total sane.
"""
import time
import requests
from dataclasses import dataclass, field
from typing import Optional

SEARCH_URL = "https://places.googleapis.com/v1/places:searchText"
DETAILS_URL = "https://places.googleapis.com/v1/places/{place_id}"

SEARCH_FIELDS = ",".join([
    "places.id", "places.displayName", "places.formattedAddress",
    "places.rating", "places.userRatingCount", "places.businessStatus",
    "places.primaryType", "places.location", "nextPageToken",
])

DETAIL_FIELDS = ",".join([
    "id", "displayName", "nationalPhoneNumber", "websiteUri",
    "rating", "userRatingCount", "businessStatus", "primaryType",
    "formattedAddress", "reviews", "regularOpeningHours",
    "location", "photos", "editorialSummary",
])


@dataclass
class Business:
    place_id: str
    name: str
    address: str
    category: str
    rating: Optional[float] = None
    review_count: int = 0
    status: str = ""
    phone: str = ""
    website: str = ""
    has_hours: bool = False
    lat: Optional[float] = None
    lng: Optional[float] = None
    photo_names: list = field(default_factory=list)
    summary: str = ""
    # ISO dates of the (up to 5) most recent reviews, newest first
    recent_review_dates: list = field(default_factory=list)
    search_location: str = ""
    search_category: str = ""


class PlacesClient:
    def __init__(self, api_key: str, pause: float = 0.15):
        self.key = api_key
        self.pause = pause

    def _headers(self, fields: str) -> dict:
        return {
            "Content-Type": "application/json",
            "X-Goog-Api-Key": self.key,
            "X-Goog-FieldMask": fields,
        }

    def search(self, category: str, location: str, max_results: int = 60) -> list[Business]:
        """Text search, paginates up to max_results (Google caps at 60)."""
        out: list[Business] = []
        body = {"textQuery": f"{category} in {location}", "pageSize": 20}
        page_token = None
        while len(out) < max_results:
            if page_token:
                body["pageToken"] = page_token
            r = requests.post(SEARCH_URL, json=body, headers=self._headers(SEARCH_FIELDS), timeout=30)
            r.raise_for_status()
            data = r.json()
            for p in data.get("places", []):
                out.append(Business(
                    place_id=p["id"],
                    name=p.get("displayName", {}).get("text", ""),
                    address=p.get("formattedAddress", ""),
                    category=p.get("primaryType", ""),
                    rating=p.get("rating"),
                    review_count=p.get("userRatingCount", 0),
                    status=p.get("businessStatus", ""),
                    lat=(p.get("location") or {}).get("latitude"),
                    lng=(p.get("location") or {}).get("longitude"),
                    search_location=location,
                    search_category=category,
                ))
            page_token = data.get("nextPageToken")
            if not page_token:
                break
            time.sleep(self.pause)
        return out[:max_results]

    def enrich(self, b: Business) -> Business:
        """Fill phone, website, hours, and recent review dates."""
        url = DETAILS_URL.format(place_id=b.place_id)
        r = requests.get(url, headers=self._headers(DETAIL_FIELDS), timeout=30)
        if r.status_code != 200:
            return b
        d = r.json()
        b.phone = d.get("nationalPhoneNumber", "") or ""
        b.website = d.get("websiteUri", "") or ""
        b.has_hours = bool(d.get("regularOpeningHours"))
        b.status = d.get("businessStatus", b.status)
        b.rating = d.get("rating", b.rating)
        b.review_count = d.get("userRatingCount", b.review_count)
        dates = []
        for rev in d.get("reviews", []):
            t = rev.get("publishTime")
            if t:
                dates.append(t)
        b.recent_review_dates = sorted(dates, reverse=True)
        loc = d.get("location") or {}
        b.lat = loc.get("latitude", b.lat)
        b.lng = loc.get("longitude", b.lng)
        b.photo_names = [ph["name"] for ph in d.get("photos", [])[:3] if ph.get("name")]
        b.summary = (d.get("editorialSummary") or {}).get("text", "")
        time.sleep(self.pause)
        return b


# ---------------------------------------------------------------- imagery

STREETVIEW_META = "https://maps.googleapis.com/maps/api/streetview/metadata"
STREETVIEW_IMG = "https://maps.googleapis.com/maps/api/streetview"
PLACE_PHOTO = "https://places.googleapis.com/v1/{photo_name}/media"


def maps_link(place_id: str) -> str:
    return f"https://www.google.com/maps/place/?q=place_id:{place_id}"


def streetview_link(lat, lng) -> str:
    if lat is None or lng is None:
        return ""
    return f"https://www.google.com/maps/@?api=1&map_action=pano&viewpoint={lat},{lng}"


class ImageClient:
    """Street View Static + Place Photos. Only called for tier A/B leads."""

    def __init__(self, api_key: str, out_dir: str = "lead_images", pause: float = 0.1):
        from pathlib import Path
        self.key = api_key
        self.out = Path(out_dir)
        self.out.mkdir(parents=True, exist_ok=True)
        self.pause = pause

    def streetview_available(self, lat, lng) -> bool:
        """FREE metadata check — never pay for a 'no imagery here' grey box."""
        if lat is None or lng is None:
            return False
        try:
            r = requests.get(STREETVIEW_META, params={
                "location": f"{lat},{lng}", "key": self.key}, timeout=15)
            return r.status_code == 200 and r.json().get("status") == "OK"
        except requests.RequestException:
            return False

    def fetch_streetview(self, place_id: str, lat, lng, size: str = "640x400") -> str:
        """Returns local file path, or '' if unavailable. Checks metadata first."""
        if not self.streetview_available(lat, lng):
            return ""
        path = self.out / f"{place_id}_street.jpg"
        if path.exists():
            return str(path)
        try:
            r = requests.get(STREETVIEW_IMG, params={
                "location": f"{lat},{lng}", "size": size, "fov": 80,
                "return_error_code": "true", "key": self.key}, timeout=30)
            if r.status_code != 200:
                return ""
            path.write_bytes(r.content)
            time.sleep(self.pause)
            return str(path)
        except requests.RequestException:
            return ""

    def fetch_place_photo(self, place_id: str, photo_name: str, max_px: int = 800) -> str:
        """Owner/customer-uploaded photo of the business. Often better than Street View."""
        path = self.out / f"{place_id}_photo.jpg"
        if path.exists():
            return str(path)
        try:
            r = requests.get(PLACE_PHOTO.format(photo_name=photo_name), params={
                "maxWidthPx": max_px, "key": self.key}, timeout=30)
            if r.status_code != 200:
                return ""
            path.write_bytes(r.content)
            time.sleep(self.pause)
            return str(path)
        except requests.RequestException:
            return ""
