"""
Orchestration.

  discover  →  enrich  →  score  →  registry  →  CSV

Run:  python -m leads.pipeline --config config.yaml
      python -m leads.pipeline --config config.yaml --skip-registry   (faster, cheaper)
      python -m leads.pipeline --config config.yaml --dry-run          (search only, no details)

Resumable: writes a checkpoint JSON after each stage so a crash at business
#400 doesn't cost you the first 399 Details calls.
"""
import argparse
import csv
import json
import sys
from dataclasses import asdict
from pathlib import Path

import yaml

from .places import PlacesClient, ImageClient, Business, maps_link, streetview_link
from .fizzle import score as fizzle_score
from .website import audit as site_audit
from .registry import RegistryClient
from .export_supabase import SupabaseExporter, build_row
from .chains import find_local_chains, chain_check
from .dnc import Suppression, in_call_window, best_time_hint

CKPT = Path(".leads_checkpoint.json")

CSV_COLUMNS = [
    "tier", "score", "name", "phone", "owner_or_principal", "city", "category",
    "rating", "review_count", "days_since_last_review", "website",
    "fizzle_reasons", "registry_legal_name", "registry_confidence",
    "registry_note", "registry_source", "maps_url", "streetview_url",
    "streetview_file", "photo_file", "best_time_to_call", "band_used",
    "place_id", "address",
]


def _city(address: str) -> str:
    parts = [p.strip() for p in address.split(",")]
    return parts[-3] if len(parts) >= 3 else ""


def load_ckpt() -> dict:
    return json.loads(CKPT.read_text()) if CKPT.exists() else {}


def save_ckpt(d: dict):
    CKPT.write_text(json.dumps(d))


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--config", default="config.yaml")
    ap.add_argument("--skip-registry", action="store_true")
    ap.add_argument("--dry-run", action="store_true")
    ap.add_argument("--fresh", action="store_true", help="ignore checkpoint")
    ap.add_argument("--images", action="store_true",
                    help="download Street View + place photos for tier A/B (costs ~$7+2/1k)")
    ap.add_argument("--push", action="store_true",
                    help="upsert results into Masterminds (Supabase)")
    args = ap.parse_args()

    cfg = yaml.safe_load(Path(args.config).read_text())
    places = PlacesClient(cfg["google_places_api_key"])
    reg = RegistryClient(cfg.get("opencorporates_api_token", ""))
    lim = cfg["limits"]
    ck = {} if args.fresh else load_ckpt()

    # ---------- 1. Discover ----------
    if "discovered" in ck:
        businesses = [Business(**b) for b in ck["discovered"]]
        print(f"[ckpt] {len(businesses)} businesses from checkpoint")
    else:
        seen, businesses = set(), []
        for loc in cfg["locations"]:
            for cat in cfg["categories"]:
                print(f"search: {cat} in {loc}")
                try:
                    found = places.search(cat, loc, lim["max_results_per_search"])
                except Exception as e:
                    print(f"  ! {e}"); continue
                new = [b for b in found if b.place_id not in seen]
                for b in new:
                    seen.add(b.place_id)
                businesses.extend(new)
                print(f"  +{len(new)} (total {len(businesses)})")
                if len(businesses) >= lim["max_businesses_total"]:
                    break
            if len(businesses) >= lim["max_businesses_total"]:
                break
        businesses = businesses[: lim["max_businesses_total"]]
        ck["discovered"] = [asdict(b) for b in businesses]
        save_ckpt(ck)

    if args.dry_run:
        print(f"dry run: {len(businesses)} businesses discovered"); return

    # ---------- 2. Enrich + 3. Score ----------
    # Cheap pre-filter BEFORE spending on Details calls
    fz = cfg["fizzle"]
    from .fizzle import bands_for
    candidates = [b for b in businesses
                  if b.review_count >= bands_for(b, fz)["floor"]
                  and (b.rating or 0) >= fz["min_rating"]
                  and b.status in ("OPERATIONAL", "")]
    local_chains = find_local_chains([b.name for b in businesses])
    if local_chains:
        print(f"multi-location operators detected in this run: {len(local_chains)}")

    pre_chain = len(candidates)
    filtered = []
    for b in candidates:
        is_chain, why = chain_check(b.name, local_chains)
        if is_chain:
            continue
        filtered.append(b)
    if pre_chain != len(filtered):
        print(f"excluded {pre_chain - len(filtered)} franchise/chain locations")
    candidates = filtered

    print(f"{len(candidates)}/{len(businesses)} pass pre-filter (per-category floors, rating>={fz['min_rating']})")

    enriched = {e["place_id"]: e for e in ck.get("enriched", [])}
    rows = []
    for i, b in enumerate(candidates, 1):
        if b.place_id in enriched:
            b = Business(**enriched[b.place_id]["business"])
            stale, issues = enriched[b.place_id]["site"]
        else:
            try:
                b = places.enrich(b)
            except Exception as e:
                print(f"  ! details {b.name}: {e}"); continue
            stale, issues = site_audit(b.website) if b.website else (None, [])
            enriched[b.place_id] = {"business": asdict(b), "site": [stale, issues]}
            if i % 10 == 0:
                ck["enriched"] = list(enriched.values()); save_ckpt(ck)

        res = fizzle_score(b, fz, stale, issues)
        print(f"[{i}/{len(candidates)}] {res.tier} {res.score:3d}  {b.name}")
        if res.tier == "X":
            continue
        rows.append((b, res))

    ck["enriched"] = list(enriched.values()); save_ckpt(ck)
    rows.sort(key=lambda t: -t[1].score)
    print(f"\n{len(rows)} qualified leads. A={sum(1 for _,r in rows if r.tier=='A')} "
          f"B={sum(1 for _,r in rows if r.tier=='B')} C={sum(1 for _,r in rows if r.tier=='C')}")

    # ---------- 4. Registry (A and B only — don't burn lookups on C) ----------
    reg_cache = ck.get("registry", {})
    out_rows = []
    push_queue = []
    imgclient = ImageClient(cfg["google_places_api_key"],
                            cfg.get("image_dir", "lead_images")) if args.images else None
    for b, res in rows:
        city = _city(b.address)
        m = None
        if not args.skip_registry and res.tier in ("A", "B"):
            if b.place_id in reg_cache:
                m = reg_cache[b.place_id]
            else:
                print(f"registry: {b.name}")
                rm = reg.lookup(b.name, city)
                m = {"legal_name": rm.legal_name, "principals": rm.principals,
                     "agent": rm.registered_agent, "confidence": rm.confidence,
                     "note": rm.note, "url": rm.source_url}
                reg_cache[b.place_id] = m
                ck["registry"] = reg_cache; save_ckpt(ck)
        m = m or {}
        owner = "; ".join(m.get("principals", [])) or (f"[agent] {m['agent']}" if m.get("agent") else "")

        mu, sv = maps_link(b.place_id), streetview_link(b.lat, b.lng)

        # Imagery: tier A/B only. Metadata check is free, so we never pay for
        # a grey "no imagery" tile.
        imgs = {}
        if args.images and res.tier in ("A", "B") and imgclient:
            sp = imgclient.fetch_streetview(b.place_id, b.lat, b.lng)
            if sp:
                imgs["street"] = sp
            if b.photo_names:
                pp = imgclient.fetch_place_photo(b.place_id, b.photo_names[0])
                if pp:
                    imgs["photo"] = pp
            if imgs:
                print(f"  img {b.name}: {', '.join(imgs.keys())}")

        out_rows.append({
            "tier": res.tier, "score": res.score, "name": b.name, "phone": b.phone,
            "owner_or_principal": owner, "city": city, "category": b.category,
            "rating": b.rating, "review_count": b.review_count,
            "days_since_last_review": res.days_since_last_review, "website": b.website,
            "fizzle_reasons": " | ".join(res.reasons),
            "registry_legal_name": m.get("legal_name", ""),
            "registry_confidence": m.get("confidence", ""),
            "registry_note": m.get("note", ""), "registry_source": m.get("url", ""),
            "maps_url": mu, "streetview_url": sv,
            "streetview_file": imgs.get("street", ""), "photo_file": imgs.get("photo", ""),
            "best_time_to_call": best_time_hint(b.search_category or b.category),
            "band_used": res.band_used,
            "place_id": b.place_id, "address": b.address,
        })
        push_queue.append((b, res, m, imgs, mu, sv))

    supp = Suppression(cfg.get("suppression_file", "do_not_call.txt"))
    out_rows, removed = supp.filter(out_rows, "phone")
    if removed:
        print(f"removed {removed} suppressed numbers")
        keep_ids = {r["place_id"] for r in out_rows}
        push_queue = [q for q in push_queue if q[0].place_id in keep_ids]

    ok, msg = in_call_window()
    print(f"call window right now: {msg}")

    out = Path(cfg["output_csv"])
    with out.open("w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=CSV_COLUMNS); w.writeheader(); w.writerows(out_rows)
    print(f"\nwrote {len(out_rows)} leads → {out}")

    # ---------- 5. Push into Masterminds ----------
    if args.push:
        sb = cfg.get("supabase", {})
        if not sb.get("url") or not sb.get("service_role_key"):
            print("!! --push set but supabase.url / supabase.service_role_key missing in config")
            return
        exp = SupabaseExporter(sb["url"], sb["service_role_key"],
                               sb.get("bucket", "lead-media"),
                               sb.get("workspace_id"))
        rows = []
        for b, res, m, imgs, mu, sv in push_queue:
            stored = {}
            for kind, path in imgs.items():
                obj = exp.upload_image(path, b.place_id, kind)
                if obj:
                    stored[kind] = obj
            rows.append(build_row(b, res, m, stored, mu, sv))
        # chunk so one big payload can't time out
        total, errs = 0, []
        for i in range(0, len(rows), 100):
            n, err = exp.upsert(rows[i:i + 100])
            total += n
            if err:
                errs.append(err)
        print(f"pushed {total}/{len(rows)} leads into Masterminds")
        for e in errs[:3]:
            print(f"  ! {e}")


if __name__ == "__main__":
    sys.exit(main())
