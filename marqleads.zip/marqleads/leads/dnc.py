"""
Call compliance and call-window helpers.

NOT LEGAL ADVICE. This reduces obvious risk; it does not make you compliant.
Read the rules yourself and talk to a lawyer before running volume.

What actually applies to B2B cold calling in the US:
  - The National DNC Registry covers RESIDENTIAL numbers. Business-to-business
    calls are largely exempt — BUT many small businesses use a cell or home
    line as their business number, and those can be registered. The exemption
    is about the call's purpose, not the number, and enforcement has been
    unkind to people who assumed otherwise.
  - Utah has its own state DNC list and its own telephone solicitation rules.
  - Calling hours: federal telemarketing rules restrict to 8am-9pm in the
    CALLED party's time zone. Utah is Mountain. Keep it 9am-6pm local anyway —
    you're calling businesses, and calling a plumber at 8:01am helps nobody.
  - If someone says stop, you stop, permanently, and you log it.

This module gives you:
  1. a local suppression list you control (do_not_call.txt)
  2. a call-window check
  3. per-business call spacing so you never look like a robodialer
"""
import re
from datetime import datetime, time
from pathlib import Path
from zoneinfo import ZoneInfo

SUPPRESSION_FILE = "do_not_call.txt"
MOUNTAIN = ZoneInfo("America/Denver")

# Conservative window. Federal floor is 8am-9pm; this is tighter on purpose.
CALL_START = time(9, 0)
CALL_END = time(18, 0)


def normalize(phone: str) -> str:
    d = re.sub(r"\D", "", phone or "")
    return d[-10:] if len(d) >= 10 else d


class Suppression:
    """Numbers you must never call again. Append-only, one per line."""

    def __init__(self, path: str = SUPPRESSION_FILE):
        self.path = Path(path)
        self.path.touch(exist_ok=True)
        self._set = {
            normalize(l) for l in self.path.read_text().splitlines()
            if l.strip() and not l.startswith("#")
        }
        self._set.discard("")

    def __contains__(self, phone: str) -> bool:
        return normalize(phone) in self._set

    def add(self, phone: str, reason: str = "requested"):
        n = normalize(phone)
        if not n or n in self._set:
            return
        self._set.add(n)
        with self.path.open("a") as f:
            f.write(f"{n}  # {reason} {datetime.now():%Y-%m-%d}\n")

    def filter(self, rows: list[dict], key: str = "phone") -> tuple[list, int]:
        keep = [r for r in rows if r.get(key) not in self]
        return keep, len(rows) - len(keep)


def in_call_window(now: datetime | None = None) -> tuple[bool, str]:
    now = now or datetime.now(MOUNTAIN)
    if now.weekday() == 6:
        return False, "Sunday — don't."
    if now.weekday() == 5:
        return False, "Saturday — most owners aren't taking sales calls."
    t = now.time()
    if t < CALL_START:
        return False, f"too early, wait until {CALL_START:%H:%M} Mountain"
    if t > CALL_END:
        return False, f"too late, window closed at {CALL_END:%H:%M} Mountain"
    return True, "ok"


def best_time_hint(category: str) -> str:
    """When this kind of owner is most likely to pick up."""
    c = (category or "").lower()
    if any(k in c for k in ("restaurant", "cafe", "bar", "food")):
        return "2-4pm — between lunch and dinner rush"
    if any(k in c for k in ("salon", "barber", "nail", "spa")):
        return "Tue-Thu 10am-noon — Mondays are often closed"
    if any(k in c for k in ("plumb", "hvac", "roof", "electric", "contractor", "landscap")):
        return "7-8am or 4-6pm — they're on jobs midday"
    if any(k in c for k in ("gym", "yoga", "fitness")):
        return "10am-2pm — between morning and evening classes"
    if any(k in c for k in ("dentist", "chiro", "medical")):
        return "call the office, ask for the practice manager"
    return "10am-noon or 2-4pm"
