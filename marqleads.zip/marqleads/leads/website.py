"""
Lightweight website audit. One GET, no crawling.

Looks for signals a site has been neglected:
  - copyright year in the footer is old
  - no HTTPS / cert redirect
  - slow response
  - obvious builders with default templates
  - dead social links
"""
import re
import time
import requests
from datetime import datetime

UA = {"User-Agent": "Mozilla/5.0 (compatible; MarqLeadAudit/1.0)"}
YEAR_RE = re.compile(r"(?:©|&copy;|copyright)\s*(?:\d{4}\s*[-–]\s*)?(20\d{2})", re.I)


def audit(url: str, timeout: int = 12) -> tuple[int | None, list[str]]:
    """Returns (estimated_days_stale or None, issues[])."""
    issues: list[str] = []
    if not url:
        return None, ["no website"]

    if url.startswith("http://"):
        issues.append("no https")

    t0 = time.time()
    try:
        r = requests.get(url, headers=UA, timeout=timeout, allow_redirects=True)
    except requests.RequestException as e:
        return None, [f"unreachable ({type(e).__name__})"]
    elapsed = time.time() - t0
    if elapsed > 5:
        issues.append(f"slow ({elapsed:.1f}s)")
    if r.status_code >= 400:
        return None, [f"http {r.status_code}"]

    html = r.text[:400_000]
    low = html.lower()

    stale_days = None
    years = [int(y) for y in YEAR_RE.findall(html)]
    if years:
        newest = max(years)
        now = datetime.now().year
        if newest < now - 1:
            stale_days = (now - newest) * 365
            issues.append(f"copyright {newest}")

    if "wix.com" in low and "wixstatic" in low:
        issues.append("wix")
    if "godaddy" in low and "website builder" in low:
        issues.append("godaddy builder")
    if "under construction" in low or "coming soon" in low:
        issues.append("under construction")
    if "<meta name=\"viewport\"" not in low:
        issues.append("not mobile-responsive")
    if "lorem ipsum" in low:
        issues.append("placeholder text live")

    return stale_days, issues
