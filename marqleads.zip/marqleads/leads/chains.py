"""
Franchise and chain exclusion.

A Subway or Great Clips location cannot hire you. Marketing is set at
corporate, the person answering is a manager with no spend authority, and
the "owner" in the registry is a multi-unit franchisee in another state.

Every one of these in your call list is wasted dial time, and they score
WELL — chains have lots of reviews and often neglected local listings.
Without this filter they'd sit at the top of your A tier.

Two checks:
  1. known-brand name match
  2. duplicate-name detection within the run (3+ locations of the same
     name = chain, even if it's a local one you've never heard of)
"""
import re
from collections import Counter

KNOWN_CHAINS = {
    # food
    "subway", "mcdonald", "burger king", "wendy", "taco bell", "kfc", "popeyes",
    "chick-fil-a", "chipotle", "panera", "starbucks", "dunkin", "dutch bros",
    "jimmy john", "jersey mike", "firehouse subs", "arby", "sonic drive",
    "little caesars", "domino", "pizza hut", "papa john", "papa murphy",
    "panda express", "in-n-out", "five guys", "culver", "del taco", "carl's jr",
    "wingstop", "buffalo wild wings", "applebee", "chili's", "olive garden",
    "red lobster", "outback", "texas roadhouse", "denny", "ihop", "village inn",
    "cafe rio", "costa vida", "swig", "sodalicious", "crumbl", "jamba",
    "smoothie king", "baskin-robbins", "cold stone", "dairy queen",
    # services
    "great clips", "supercuts", "sport clips", "fantastic sams", "cost cutters",
    "massage envy", "european wax", "drybar", "regis salon",
    "anytime fitness", "planet fitness", "gold's gym", "24 hour fitness",
    "orangetheory", "f45", "club pilates", "vasa fitness", "eos fitness",
    "jiffy lube", "valvoline", "midas", "meineke", "firestone", "big o tires",
    "les schwab", "discount tire", "aamco", "maaco",
    "servpro", "servicemaster", "stanley steemer", "chem-dry", "molly maid",
    "merry maids", "the maids", "mr. rooter", "roto-rooter", "benjamin franklin",
    "one hour heating", "aire serv", "mr. handyman", "handyman connection",
    "lawn doctor", "trugreen", "weed man",
    # retail / other
    "7-eleven", "circle k", "maverik", "chevron", "sinclair", "smith's",
    "harmons", "walmart", "target", "walgreens", "cvs", "rite aid",
    "gnc", "vitamin shoppe", "verizon", "t-mobile", "at&t store",
    "h&r block", "jackson hewitt", "liberty tax",
    "aspen dental", "smile brands", "western dental",
    "the joint chiropractic", "petsmart", "petco", "pet supplies plus",
}

_NORM = re.compile(r"[^a-z0-9 ]")


def _norm(name: str) -> str:
    n = _NORM.sub(" ", (name or "").lower())
    return re.sub(r"\s+", " ", n).strip()


def is_known_chain(name: str) -> tuple[bool, str]:
    n = _norm(name)
    for brand in KNOWN_CHAINS:
        b = _norm(brand)
        if b and (n.startswith(b) or f" {b} " in f" {n} "):
            return True, brand
    return False, ""


def find_local_chains(names: list[str], threshold: int = 3) -> set[str]:
    """Names appearing threshold+ times in one run = multi-location operator.
    Catches regional chains not in the known list."""
    counts = Counter(_norm(n) for n in names if n)
    return {n for n, c in counts.items() if c >= threshold and n}


def chain_check(name: str, local_chains: set[str]) -> tuple[bool, str]:
    known, brand = is_known_chain(name)
    if known:
        return True, f"franchise/chain ({brand}) — no local marketing authority"
    if _norm(name) in local_chains:
        return True, "multi-location operator in this run — likely not a single-owner decision"
    return False, ""
