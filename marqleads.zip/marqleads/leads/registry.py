"""
Owner / principal lookup from the Utah business registry.

Uses OpenCorporates, which mirrors the Utah Division of Corporations data
including officers/principals. Free tier is rate-limited (~500/mo); a token
raises that. Unauthenticated calls work for small batches.

The match problem — why this used to be 30%:
  Registry names rarely equal the storefront name. "Maria's Tacos" might be
  registered as "MTR Holdings LLC". We can't fix that fully, but we can:
    1. Try the exact name, then progressively looser variants
    2. Require the registry address to share a city with the storefront
    3. Fuzzy-score and keep only confident matches
    4. Flag "registered agent" entries — those are often lawyers, not owners

When no confident match: leave owner blank. You still have the business phone.
Calling and asking "who's the owner?" beats calling the wrong person by name.

Alternative if you want bulk: Utah sells its full corporate database as a
flat file (Division of Corporations → Data Sales). One purchase, local
fuzzy-match against 500k rows, no API limits. Worth it past ~1k leads.
"""
import re
import time
import requests
from dataclasses import dataclass
from difflib import SequenceMatcher


def _token_set_ratio(a: str, b: str) -> int:
    """rapidfuzz.fuzz.token_set_ratio equivalent using stdlib only."""
    ta, tb = set(a.split()), set(b.split())
    inter = " ".join(sorted(ta & tb))
    ra = " ".join(sorted(ta - tb))
    rb = " ".join(sorted(tb - ta))
    s1 = f"{inter} {ra}".strip(); s2 = f"{inter} {rb}".strip()
    def r(x, y): return int(100 * SequenceMatcher(None, x, y).ratio())
    return max(r(inter, s1), r(inter, s2), r(s1, s2)) if inter else r(a, b)

OC_SEARCH = "https://api.opencorporates.com/v0.4/companies/search"
OC_COMPANY = "https://api.opencorporates.com/v0.4/companies/{juris}/{num}"

SUFFIXES = re.compile(r"\b(llc|l\.l\.c\.|inc|incorporated|corp|corporation|co|ltd|dba)\b\.?", re.I)
NOISE = re.compile(r"\b(the|and|&|of|restaurant|cafe|salon|studio|shop|bar|grill)\b", re.I)


@dataclass
class RegistryMatch:
    legal_name: str = ""
    principals: list[str] = None
    registered_agent: str = ""
    status: str = ""
    confidence: int = 0          # 0–100 fuzzy score
    source_url: str = ""
    note: str = ""

    def __post_init__(self):
        if self.principals is None:
            self.principals = []


def _normalize(name: str) -> str:
    n = SUFFIXES.sub("", name)
    n = NOISE.sub("", n)
    n = re.sub(r"[^a-z0-9 ]", " ", n.lower())
    return re.sub(r"\s+", " ", n).strip()


def _variants(name: str) -> list[str]:
    base = _normalize(name)
    out = [name, base]
    words = base.split()
    if len(words) > 2:
        out.append(" ".join(words[:2]))
    if words:
        out.append(words[0])
    seen, uniq = set(), []
    for v in out:
        if v and v not in seen:
            seen.add(v); uniq.append(v)
    return uniq


class RegistryClient:
    def __init__(self, token: str = "", pause: float = 1.2, jurisdiction: str = "us_ut"):
        self.token = token
        self.pause = pause
        self.juris = jurisdiction

    def _params(self, **kw) -> dict:
        p = dict(kw)
        if self.token:
            p["api_token"] = self.token
        return p

    def lookup(self, business_name: str, city: str) -> RegistryMatch:
        best = RegistryMatch()
        norm_target = _normalize(business_name)

        for q in _variants(business_name):
            try:
                r = requests.get(OC_SEARCH, params=self._params(
                    q=q, jurisdiction_code=self.juris, per_page=10), timeout=30)
                time.sleep(self.pause)
                if r.status_code != 200:
                    continue
                companies = r.json().get("results", {}).get("companies", [])
            except requests.RequestException:
                continue

            for c in companies:
                co = c.get("company", {})
                legal = co.get("name", "")
                score = _token_set_ratio(norm_target, _normalize(legal))
                # city gate: registry address should mention the storefront city
                addr = (co.get("registered_address_in_full") or "").lower()
                if city and city.lower().split(",")[0] not in addr:
                    score -= 15
                if co.get("current_status", "").lower() not in ("active", "good standing", ""):
                    score -= 25
                if score > best.confidence:
                    best = RegistryMatch(
                        legal_name=legal,
                        status=co.get("current_status", ""),
                        confidence=int(max(score, 0)),
                        source_url=co.get("opencorporates_url", ""),
                    )
                    best._num = co.get("company_number", "")
            if best.confidence >= 85:
                break

        if best.confidence < 70:
            best.note = "no confident registry match — call and ask for owner"
            return best

        # Pull officers/principals
        try:
            r = requests.get(OC_COMPANY.format(juris=self.juris, num=best._num),
                             params=self._params(), timeout=30)
            time.sleep(self.pause)
            if r.status_code == 200:
                officers = r.json().get("results", {}).get("company", {}).get("officers", [])
                for o in officers:
                    off = o.get("officer", {})
                    nm, pos = off.get("name", ""), (off.get("position") or "").lower()
                    if not nm:
                        continue
                    if "agent" in pos:
                        best.registered_agent = nm
                    else:
                        best.principals.append(f"{nm} ({pos})" if pos else nm)
        except requests.RequestException:
            pass

        if not best.principals and best.registered_agent:
            best.note = "only a registered agent listed — may be a lawyer/formation service, not the owner"
        return best
