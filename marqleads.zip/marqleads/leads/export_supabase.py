"""
Push scored leads into Masterminds (Supabase).

Creates/updates rows in a `leads` table and uploads imagery to the
`lead-media` storage bucket, so leads show up in the app with photos
and a one-tap call button.

Run the SQL in schema.sql first (see repo root).

Uses the SERVICE ROLE key, not the anon key — this writes server-side and
bypasses RLS. Keep it in config.yaml, never in the app bundle, never in git.
"""
import json
import mimetypes
from pathlib import Path
from typing import Optional
import requests


class SupabaseExporter:
    def __init__(self, url: str, service_key: str, bucket: str = "lead-media",
                 workspace_id: Optional[str] = None):
        self.url = url.rstrip("/")
        self.key = service_key
        self.bucket = bucket
        self.workspace_id = workspace_id

    # ------------------------------------------------------------ helpers
    def _h(self, extra: dict = None) -> dict:
        h = {
            "apikey": self.key,
            "Authorization": f"Bearer {self.key}",
            "Content-Type": "application/json",
        }
        if extra:
            h.update(extra)
        return h

    # ------------------------------------------------------------ storage
    def upload_image(self, local_path: str, place_id: str, kind: str) -> str:
        """Upload to storage, return the object path (not a public URL —
        bucket stays private, app generates signed URLs)."""
        p = Path(local_path)
        if not p.exists():
            return ""
        obj = f"leads/{place_id}/{kind}{p.suffix}"
        ctype = mimetypes.guess_type(p.name)[0] or "image/jpeg"
        r = requests.post(
            f"{self.url}/storage/v1/object/{self.bucket}/{obj}",
            headers={
                "apikey": self.key,
                "Authorization": f"Bearer {self.key}",
                "Content-Type": ctype,
                "x-upsert": "true",
            },
            data=p.read_bytes(),
            timeout=60,
        )
        return obj if r.status_code in (200, 201) else ""

    # ------------------------------------------------------------ rows
    def upsert(self, rows: list[dict]) -> tuple[int, str]:
        """Upsert on place_id. Returns (count_written, error_text)."""
        if not rows:
            return 0, ""
        if self.workspace_id:
            for r in rows:
                r["workspace_id"] = self.workspace_id
        resp = requests.post(
            f"{self.url}/rest/v1/leads",
            headers=self._h({
                "Prefer": "resolution=merge-duplicates,return=minimal",
            }),
            params={"on_conflict": "place_id"},
            data=json.dumps(rows),
            timeout=60,
        )
        if resp.status_code in (200, 201, 204):
            return len(rows), ""
        return 0, f"{resp.status_code}: {resp.text[:400]}"


def build_row(b, res, registry: dict, images: dict, maps_url: str, sv_url: str) -> dict:
    """Map a scored business into the leads table shape."""
    principals = registry.get("principals") or []
    agent = registry.get("agent") or ""
    return {
        "place_id": b.place_id,
        "business_name": b.name,
        "phone": b.phone,
        "owner_name": "; ".join(principals) or "",
        "owner_is_agent_only": bool(agent and not principals),
        "registered_agent": agent,
        "registry_legal_name": registry.get("legal_name", ""),
        "registry_confidence": registry.get("confidence") or None,
        "registry_note": registry.get("note", ""),
        "registry_url": registry.get("url", ""),
        "address": b.address,
        "city": (b.address.split(",")[-3].strip() if len(b.address.split(",")) >= 3 else ""),
        "lat": b.lat,
        "lng": b.lng,
        "category": b.category,
        "search_category": b.search_category,
        "website": b.website,
        "summary": b.summary,
        "rating": b.rating,
        "review_count": b.review_count,
        "days_since_last_review": res.days_since_last_review,
        "fizzle_score": res.score,
        "tier": res.tier,
        "fizzle_reasons": res.reasons,
        "maps_url": maps_url,
        "streetview_url": sv_url,
        "streetview_path": images.get("street", ""),
        "photo_path": images.get("photo", ""),
        "status": "new",
    }
