"""
Fizzle scoring.

The pitch is for businesses that WERE good and lost momentum — not ones that
were always struggling. So we need BOTH signals:

  1. Evidence of a strong period  → review count HIGH FOR ITS CATEGORY, decent rating
  2. Evidence of falloff          → most recent review is old, site is stale

Google only returns the 5 most recent reviews, so we can't see the full curve.
But (many total reviews) + (newest review is 8 months old) IS the curve.

WHY PER-CATEGORY FLOORS:
Review rates differ hugely by business type. A restaurant collects roughly one
review per 100-200 customers; a plumber serves far fewer customers at much
higher ticket and often gets a review from a decent fraction of them. A plumber
with 40 reviews is well established. A restaurant with 40 reviews is small.
One flat threshold throws away good trade leads and lets weak restaurants in.

Score 0-100. Higher = better fit for the pitch.
"""
from dataclasses import dataclass
from datetime import datetime, timezone
from dateutil import parser as dtparse
from .places import Business


# Review-volume bands by category.
#   floor  = below this they never had a strong period → disqualify
#   strong = at/above this they clearly had a real customer base → full points
CATEGORY_BANDS = {
    # High-volume, high-review-rate
    "restaurant":      {"floor": 40, "strong": 250},
    "cafe":            {"floor": 40, "strong": 200},
    "coffee shop":     {"floor": 40, "strong": 200},
    "bar":             {"floor": 40, "strong": 200},
    "gym":             {"floor": 35, "strong": 150},
    "yoga studio":     {"floor": 30, "strong": 120},

    # Mid
    "hair salon":      {"floor": 25, "strong": 120},
    "barbershop":      {"floor": 25, "strong": 120},
    "nail salon":      {"floor": 25, "strong": 120},
    "spa":             {"floor": 25, "strong": 120},
    "boutique":        {"floor": 20, "strong": 90},
    "pet grooming":    {"floor": 20, "strong": 90},
    "dry cleaner":     {"floor": 20, "strong": 80},

    # Low-volume, high-ticket trades — an established business here runs on
    # far fewer reviews than a restaurant ever would
    "plumber":         {"floor": 15, "strong": 80},
    "hvac":            {"floor": 15, "strong": 80},
    "roofing":         {"floor": 15, "strong": 70},
    "electrician":     {"floor": 15, "strong": 80},
    "landscaping":     {"floor": 15, "strong": 70},
    "house cleaning":  {"floor": 15, "strong": 70},
    "handyman":        {"floor": 12, "strong": 60},
    "contractor":      {"floor": 12, "strong": 60},
    "auto repair":     {"floor": 30, "strong": 150},

    # Professional
    "dentist":         {"floor": 25, "strong": 150},
    "chiropractor":    {"floor": 25, "strong": 130},
    "tax preparation": {"floor": 15, "strong": 70},
}

DEFAULT_BAND = {"floor": 25, "strong": 120}


def bands_for(b: Business, cfg: dict) -> dict:
    """Resolve the review band for this business. Config can override."""
    overrides = (cfg.get("category_bands") or {})
    for key in (b.search_category or "", b.category or ""):
        k = key.lower().replace("_", " ").strip()
        if not k:
            continue
        if k in overrides:
            return overrides[k]
        if k in CATEGORY_BANDS:
            return CATEGORY_BANDS[k]
        for name, band in CATEGORY_BANDS.items():
            if name in k or k in name:
                return band
    return overrides.get("default", cfg.get("default_band", DEFAULT_BAND))


@dataclass
class FizzleResult:
    score: int
    tier: str            # "A" strong fit, "B" possible, "C" weak, "X" disqualified
    days_since_last_review: int | None
    reasons: list[str]
    disqualified_reason: str = ""
    band_used: str = ""


def _days_since(iso: str) -> int:
    dt = dtparse.isoparse(iso)
    if dt.tzinfo is None:
        dt = dt.replace(tzinfo=timezone.utc)
    return (datetime.now(timezone.utc) - dt).days


def _burst_rate(b: Business) -> float | None:
    """Reviews per month during their final active stretch.

    Google gives the 5 newest reviews. The span between the oldest and newest
    of those five tells us how fast reviews were arriving RIGHT BEFORE the
    business went quiet. That's the number that says whether they fell from a
    height or were always trickling.

    We deliberately don't try to compute a "lifetime pace" — we don't know how
    old the business is, and guessing produced nonsense. This is directly
    measurable from what Google actually returns.
    """
    dates = b.recent_review_dates or []
    if len(dates) < 3:
        return None
    newest, oldest = _days_since(dates[0]), _days_since(dates[-1])
    span_days = oldest - newest
    if span_days <= 0:
        return None
    return (len(dates) - 1) / (span_days / 30.0)


def _expected_rate(band: dict) -> float:
    """Roughly what a healthy business of this category pulls per month.

    Derived from the band's 'strong' mark spread over ~4 years of operation.
    A restaurant at strong=250 implies ~5/month. A plumber at strong=80
    implies ~1.7/month. Same fall looks different across categories, so the
    comparison has to be category-relative.
    """
    return max(band.get("strong", 120) / 48.0, 0.3)


def score(b: Business, cfg: dict, website_stale_days: int | None = None,
          website_issues: list[str] | None = None) -> FizzleResult:
    reasons: list[str] = []
    website_issues = website_issues or []
    band = bands_for(b, cfg)
    floor, strong = band["floor"], band["strong"]
    cat = b.search_category or b.category or "unknown"
    band_label = f"{cat}: floor {floor}, strong {strong}"

    # ---- Hard disqualifiers ----
    if b.status and b.status != "OPERATIONAL":
        return FizzleResult(0, "X", None, [], f"status={b.status}", band_label)
    if b.review_count < floor:
        return FizzleResult(0, "X", None, [],
                            f"{b.review_count} reviews, below {floor} floor for {cat} — never had a strong period",
                            band_label)
    if b.rating is not None and b.rating < cfg["min_rating"]:
        return FizzleResult(0, "X", None, [],
                            f"rating {b.rating} — product may be the problem", band_label)
    if not b.phone:
        return FizzleResult(0, "X", None, [], "no phone number", band_label)

    s = 0

    # ---- Strong-period evidence, RELATIVE to category (0-40) ----
    ratio = b.review_count / strong if strong else 0
    if ratio >= 1.0:
        s += 35; reasons.append(f"{b.review_count} reviews — top of range for a {cat}")
    elif ratio >= 0.6:
        s += 28; reasons.append(f"{b.review_count} reviews — solid for a {cat}")
    elif ratio >= 0.35:
        s += 20; reasons.append(f"{b.review_count} reviews — established")
    else:
        s += 10; reasons.append(f"{b.review_count} reviews — modest but qualifying")

    if b.rating and b.rating >= 4.5:
        s += 5; reasons.append(f"rating {b.rating} — product is good")

    # ---- Falloff evidence: WINDOWED (0-45) ----
    # The pitch is "you were good, let's get it back." That lands hardest on a
    # business that went quiet 5-12 months ago and still feels the sting.
    # Quiet for 3 years isn't fizzling — it's mostly dead, and it's a different
    # conversation. So the score PEAKS in the window and DECAYS past it.
    still_active = False
    never_fell = False
    win = cfg.get("fizzle_window", {})
    w_start = win.get("start_days", 150)     # ~5 months
    w_end = win.get("end_days", 365)         # ~12 months
    w_dead = win.get("dead_days", 730)       # past 2y, probably not your pitch

    days = None
    if b.recent_review_dates:
        days = _days_since(b.recent_review_dates[0])
        if days < 60:
            still_active = True
            reasons.append(f"last review {days}d ago — still active, not fizzling")
        elif days < w_start:
            pts = int(18 * (days - 60) / max(w_start - 60, 1))
            s += pts; reasons.append(f"last review {days}d ago — early slowdown")
        elif days <= w_end:
            s += 45
            reasons.append(f"last review {days}d ago — IN WINDOW, fell off {days//30} months ago")
        elif days <= w_dead:
            # decay 45 -> 15 across the post-window stretch
            frac = (days - w_end) / max(w_dead - w_end, 1)
            s += int(45 - 30 * frac)
            reasons.append(f"last review {days}d ago — past ideal window ({days//30} months)")
        else:
            s += 5
            reasons.append(f"last review {days//30} months ago — likely dormant, not fizzling")
    else:
        s += 12; reasons.append("review dates unavailable")

    # ---- Fall-from-height: were they BUSY before going quiet? (0-20) ----
    # A place pulling 5 reviews a month that stopped fell from a real height.
    # A place that trickled 0.3/month for years didn't fall — it was always
    # slow, and "let's get back to what you had" is the wrong pitch for them.
    rate = _burst_rate(b)
    if rate is not None:
        expected = _expected_rate(band)
        ratio = rate / expected
        if ratio >= 1.5:
            s += 20; reasons.append(f"was pulling {rate:.1f} reviews/mo before going quiet — fell from a height")
        elif ratio >= 0.9:
            s += 14; reasons.append(f"was at {rate:.1f} reviews/mo — healthy for a {cat}, then stopped")
        elif ratio >= 0.5:
            s += 7; reasons.append(f"was at {rate:.1f} reviews/mo — moderate pace before the drop")
        else:
            never_fell = True
            reasons.append(f"only {rate:.1f} reviews/mo even when active — was always slow, not a falloff")

    # ---- Website staleness (0-20) ----
    if website_stale_days is not None and website_stale_days > 365:
        s += 12; reasons.append(f"website ~{website_stale_days // 365}y stale")
    if not b.website:
        s += 8; reasons.append("no website listed")
    for issue in website_issues[:3]:
        s += 3; reasons.append(f"site: {issue}")

    s = min(s, 100)

    # Caps. The pitch is "you were good and fell off." Two situations fail that
    # premise no matter how good the other numbers look:
    #   - still active: nothing to win back, wrong conversation
    #   - always slow: they never had the height to fall from
    # These get capped rather than disqualified — worth a call eventually,
    # never worth calling first.
    if still_active:
        s = min(s, 45)
        reasons.append("capped: still active, pitch doesn't apply yet")
    elif never_fell:
        s = min(s, 62)
        reasons.append("capped: no real falloff to point at")

    if s >= 70:   tier = "A"
    elif s >= 50: tier = "B"
    else:         tier = "C"

    return FizzleResult(s, tier, days, reasons, "", band_label)
